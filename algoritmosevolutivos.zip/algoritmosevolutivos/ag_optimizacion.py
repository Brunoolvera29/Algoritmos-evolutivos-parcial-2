"""
===============================================================================
TECNOLÓGICO DE ESTUDIOS SUPERIORES DE IXTAPALUCA
Materia: Algoritmos Evolutivos - 2do Parcial
Actividad 3: Implementacion Practica de Algoritmo Genetico
===============================================================================
"""

import json
import random
import matplotlib.pyplot as plt
import numpy as np

def cargar_configuracion(ruta_config="config.json"):
    """Carga parametros de configuracion JSON."""
    try:
        with open(ruta_config, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {
            "poblacion_tamano": 50,
            "generaciones": 100,
            "probabilidad_cruce": 0.85,
            "probabilidad_mutacion": 0.02,
            "semilla": 42,
            "longitud_bits": 16,
            "rango_x": [-1.0, 2.0]
        }

def funcion_aptitud(x):
    """Funcion Objetivo: f(x) = x * sin(10 * pi * x) + 1.0 en [-1, 2]."""
    return x * np.sin(10 * np.pi * x) + 1.0

def decodificar_binario(cromosoma, rango_x, bits):
    """Mapea una cadena binaria a un valor real."""
    valor_int = int("".join(map(str, cromosoma)), 2)
    max_int = (2**bits) - 1
    return rango_x[0] + (valor_int / max_int) * (rango_x[1] - rango_x[0])

def ejecutar_ag(config):
    """Ejecuta el ciclo generacional del AG."""
    random.seed(config["semilla"])
    np.random.seed(config["semilla"])
    
    pop_size = config["poblacion_tamano"]
    generaciones = config["generaciones"]
    p_cruce = config["probabilidad_cruce"]
    p_mut = config["probabilidad_mutacion"]
    bits = config["longitud_bits"]
    rango_x = config["rango_x"]

    poblacion = [[random.randint(0, 1) for _ in range(bits)] for _ in range(pop_size)]
    
    historial_mejor = []
    historial_promedio = []
    mejor_solucion_global = None
    mejor_aptitud_global = float("-inf")

    for gen in range(generaciones):
        valores_x = [decodificar_binario(ind, rango_x, bits) for ind in poblacion]
        aptitudes = [funcion_aptitud(x) for x in valores_x]

        max_apt = max(aptitudes)
        avg_apt = sum(aptitudes) / pop_size
        historial_mejor.append(max_apt)
        historial_promedio.append(avg_apt)

        idx_mejor = int(np.argmax(aptitudes))
        if max_apt > mejor_aptitud_global:
            mejor_aptitud_global = max_apt
            mejor_solucion_global = (valores_x[idx_mejor], poblacion[idx_mejor])

        # Seleccion por Ruleta
        aptitud_min = min(aptitudes)
        aptitudes_pos = [a - aptitud_min + 1e-6 for a in aptitudes]
        suma_apt = sum(aptitudes_pos)
        probs = [a / suma_apt for a in aptitudes_pos]
        
        indices_sel = np.random.choice(range(pop_size), size=pop_size, p=probs)
        nueva_poblacion = [poblacion[i][:] for i in indices_sel]

        # Cruce
        for i in range(0, pop_size - 1, 2):
            if random.random() < p_cruce:
                punto = random.randint(1, bits - 1)
                hijo1 = nueva_poblacion[i][:punto] + nueva_poblacion[i+1][punto:]
                hijo2 = nueva_poblacion[i+1][:punto] + nueva_poblacion[i][punto:]
                nueva_poblacion[i] = hijo1
                nueva_poblacion[i+1] = hijo2

        # Mutacion
        for i in range(pop_size):
            for j in range(bits):
                if random.random() < p_mut:
                    nueva_poblacion[i][j] = 1 - nueva_poblacion[i][j]

        poblacion = nueva_poblacion

    return mejor_solucion_global, mejor_aptitud_global, historial_mejor, historial_promedio

if __name__ == "__main__":
    configuracion = cargar_configuracion()
    (mejor_x, mejor_gen), mejor_f, h_best, h_avg = ejecutar_ag(configuracion)

    print("\n--- RESULTADOS OBETNIDOS ---")
    print(f"Mejor x encontrado: {mejor_x:.6f}")
    print(f"Mejor aptitud f(x): {mejor_f:.6f}")
    print(f"Cromosoma: {''.join(map(str, mejor_gen))}")

    plt.figure(figsize=(8, 4))
    plt.plot(h_best, label="Mejor Aptitud", color="blue")
    plt.plot(h_avg, label="Aptitud Promedio", color="orange", linestyle="--")
    plt.title("Convergencia del Algoritmo Genético")
    plt.xlabel("Generación")
    plt.ylabel("Aptitud")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig("convergencia.png")
    plt.show()